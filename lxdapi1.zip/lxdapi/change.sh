#!/bin/bash
pip install --upgrade pip
if [ -f ssh/itcloud ]
then
  chmod 600 ssh/itcloud && echo "Permission changed"
else
  echo "File doesn't exists"
fi
