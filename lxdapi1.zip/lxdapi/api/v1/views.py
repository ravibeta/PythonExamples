from django.views.decorators.csrf import csrf_exempt
from lxdapi import settings
if 'test' not in settings.ENVIRONMENT:
   from cloudapi_utils.models import User
   from cloudapi_utils.serializers import UserSerializer
else:
   from django.contrib.auth.models import User
   from api.v1.serializers import DjangoUserSerializer
from django.core import serializers
from django.http import Http404, HttpResponse, QueryDict
from django.shortcuts import render
from rest_framework import exceptions, filters, generics, status, viewsets
from rest_framework.decorators import detail_route, api_view
from rest_framework.response import Response
import logging
logging.basicConfig()
logger = logging.getLogger(__name__)

# Create your views here.

key = settings.GRPMGR_API_KEY 
import requests
import time
import requests
import json
import urllib
import base64
import datetime
import os

#constant
base_cname=settings.GRPMGR_SERVER
origin=settings.GRPMGR_ORIGIN 
destination = settings.GRPMGR_DEST 
sharedSecret = settings.GRPMGR_SECRET 

class ContainerViewSet(viewsets.ModelViewSet):

  def all(self):
      text = self.cmd_execute(["lxc list"])
      logger.info("lxc list returned: " + text)
      text = text.split("\n")
      containers = []
      keys = []
      for line in text:
          if ((line.strip().startswith('+') == False) and (
               "NAME|STATUS" not in line.strip().replace(" ",""))):
               container = {}
               parts = [ x.strip() for x in line.split('|') if x ]
               container["NAME"] = parts[0]
               container["STATUS"] = parts[1]
               container["IPV4"] = parts[2]
               containers.append(container)
      return containers
      pass


  def get_by_name(self, name):
      container = None
      print('get_by_name', 'name')
      containers = self.all()
      for item in containers:
          if item["NAME"] == name:
             container = item
      logger.info('container found by name: ' + repr(container))
      return container

  def list(self, request):
    import json
    containers = []
    retval = {'status':'error', 'msg':'Operation Failed.', 'containers': containers}
    try:

        email = request.META.get('HTTP_X_LDAP', '')
        if email:
           logger.info('requested by ' + email)
        else:
           retval['msg'] = 'Unauthorized.'
           return  HttpResponse(json.dumps(retval),
                   status=401)

        containers = self.all()
        #base_url = base_cname 
        #info = { 'url' : base_url,
        #         'headers' : headers,
        #       }
        #logger.info(repr(info))
        #r = requests.get(base_url, headers=headers)
        #logger.info("\r\n" + str(r.status_code) + " : " + repr(r.text))
        #status = r.status_code
        #content = r.text
        return HttpResponse(json.dumps(containers))
    except:
        import sys
        exc_type, exc_value, exc_traceback = sys.exc_info()
        import traceback
        msg = repr(traceback.format_exception(exc_type, exc_value, exc_traceback))
        logger.warn(msg)
        import json
        retval['msg'] = msg
        return HttpResponse(json.dumps(retval), 
               status=500)
    finally:
        pass
  
  def create(self, request):
    import json
    container = []
    name = ''
    retval = {'status':'error', 'msg':'Operation Failed.', 'name': name}
    try:

        email = request.META.get('HTTP_X_LDAP', '')
        if email:
           logger.info('requested by ' + email)
        else:
           retval['msg'] = 'Unauthorized.'
           return  HttpResponse(json.dumps(retval),
                   status=401)

        name = request.data.get('name', '')
        if name:
           logger.info('requesting container by name :' + name)
        else:
           retval['msg'] = 'Invalid name.'
           return  HttpResponse(json.dumps(retval),
                   status=400)
        name = email + "_" + name
        text = self.cmd_execute(["lxc launch ubuntu:14.04 " + name])
        #logger.info("lxc launch returned: " + text)

        container = self.get_by_name(name)
        if container == None:
           retval['msg'] = 'Create container failed.'
           return  HttpResponse(json.dumps(retval),
                   status=500)
        if 'test' not in os.sys.argv:
            self.mail_notify("confirm.html", email, container["NAME"], container["IPV4"])
        retval['msg'] = 'success'
        retval['container'] = container
        return HttpResponse(retval)
    except:
        import sys
        exc_type, exc_value, exc_traceback = sys.exc_info()
        import traceback
        msg = repr(traceback.format_exception(exc_type, exc_value, exc_traceback))
        logger.warn(msg)
        import json
        retval['msg'] = msg
        return HttpResponse(json.dumps(retval),
               status=500)
    finally:
        pass
  
  @detail_route(methods=['post'], url_path='purge')
  def purge(self, request, pk=None):
    import json
    container = []
    name = ''
    retval = {'status':'error', 'msg':'Operation Failed.', 'name': name}
    try:
        owner = 'rajamani'
    
        email = request.META.get('HTTP_X_LDAP', '')
        if email:
           logger.info('requested by ' + email)
        else:
           retval['msg'] = 'Unauthorized.'
           return  HttpResponse(json.dumps(retval),
                   status=401)
     
        name = request.data.get('name', '')
        if name:
           logger.info('requesting container by name :' + name)
        else:
           retval['msg'] = 'Invalid name.'
           return  HttpResponse(json.dumps(retval), 
                   status=400)

        #container = self.get_by_name(name)
        #if container == None:
        #   retval['msg'] = 'Container not found.'
        #   return  HttpResponse(json.dumps(retval),
        #           status=400)
 
        if email not in name:
           retval['msg'] = 'Container not owned.'
           return  HttpResponse(json.dumps(retval),
                   status=400)
           
        text = self.cmd_execute(["lxc delete " + name])
     
        container = self.get_by_name(name)
        if container != None:
           retval['msg'] = 'Delete failed.'
           return  HttpResponse(json.dumps(retval),
                   status=500)

        self.cleanup_session_files(email, name)

        if 'test' not in os.sys.argv:
            self.mail_notify("bye.html", email, container["NAME"], container["IPV4"])
        retval['msg'] = 'success'
        retval['container'] = container
        return HttpResponse(retval)
    except:
        import sys
        exc_type, exc_value, exc_traceback = sys.exc_info()
        import traceback
        msg = repr(traceback.format_exception(exc_type, exc_value, exc_traceback))
        logger.warn(msg)
        import json
        retval['msg'] = msg
        return HttpResponse(json.dumps(retval),
               status=500)
    finally:
        pass 


  def cleanup_session_files(self, email, name):
        from os import listdir, remove
        from os.path import isfile, join
        path = "/var/log/lxdsessions/"
        name_prefix = email+"_"+name
        sessionfiles = [f for f in listdir(path) if f.startswith(name_prefix)]
        logger.info('deleting session files: ' + repr(sessionfiles))
        for f in sessionfiles:
            remove(join(path,f))

  def mail_notify(self, template="confirm.html", owner="", name="", ipv4=""):
        import smtplib
        from email.mime.text import MIMEText
        from email.mime.multipart import MIMEMultipart
        me = settings.ITC_DEV_MAIL
        you = settings.ADMIN_EMAIL
        text = ''
        with open ("confirm.html", "r") as myfile:
            for line in myfile:
                text = text + line
        text = text.replace("<owner>", owner)
        text = text.replace("<name>", name)
        text = text.replace("<ipv4>", ipv4)
        message = MIMEMultipart('alternative')
        msg = MIMEText(text, 'html')
        message['Subject'] = settings.EMAIL_SUBJECT
        message['From'] = me
        message['To'] = you
        message.preamble = 'This is a multi-part message in MIME format.'
        message.attach(msg)
        s = smtplib.SMTP(settings.EMAIL_HOST)
        try:
           s.sendmail(me, [you], message.as_string())
           return True
        except:
           self.logger.info('Failed to send mail.')
           return False
      


  def cmd_execute(self, cmds):
        import shlex, subprocess
        from threading import Timer
        from subprocess import Popen, PIPE
  
        args = shlex.split(cmds[0])
        print(args)
        process = subprocess.Popen(args, stdin = subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        kill_proc = lambda p: p.kill()
        timer = Timer(10, kill_proc, [process])
        output = ''
        try:
          timer.start()
          for i in range (1,len(cmds)):
             process.stdin.write(str.encode(cmds[i]))
          output, stderr = process.communicate()
          output = output.decode('utf-8')
        finally:
          timer.cancel()
        return output
  
  
  
  @detail_route(methods=['post'], url_path='cmd')
  def cmd(self, request, pk=None):
    import json
    container = []
    command = ''
    retval = {'status':'error', 'msg':'Opertion Failed.', 'command': command}
    try:

        email = request.META.get('HTTP_X_LDAP', '')
        if email:
           logger.info('requested by ' + email)
        else:
           retval['msg'] = 'Unauthorized.'
           return  HttpResponse(json.dumps(retval),
                   status=401)

        command = request.data.get('command', '')
        if command:
           retval['command'] = command
           logger.info('requesting output for command :' + command)
        else:
           retval['msg'] = 'Invalid command.'
           return  HttpResponse(json.dumps(retval),
                   status=400)

        name = request.data.get('name', '')
        if name:
           logger.info('requesting container by name :' + name)
        else:
           retval['msg'] = 'Invalid name.'
           return  HttpResponse(json.dumps(retval),
                   status=400)

        session_key = ''
        new_session = request.data.get('newsession', '')
        if new_session:
           import random
           import string
           session_key = ''.join([random.choice(string.digits + string.ascii_uppercase)
                        for x in range(0, 12)])
           retval['sessionkey'] = session_key
           name = "/var/log/lxdsessions/"+email+"_"+name+"_"+session_key
           with open(name, "a") as f:
                f.write("Console for "+ name + "\n")
          
        text = self.cmd_execute(["lxc exec " +  name  + " -- /bin/bash",
                                 command,
                                 "exit"])

        if not session_key:
           session_key = request.data.get('sessionkey', session_key)
           retval['sessionkey'] = session_key
        print('session_key='+session_key)
        if session_key:
           import os.path
           name = "/var/log/lxdsessions/"+email+"_"+name+"_"+session_key
           if os.path.isfile(name):
              with open(name, "a") as f:
                   f.write(command+"\n")
                   f.write(text+"\n")

        retval['status'] = 'success'
        retval['msg'] = text
        return HttpResponse(json.dumps(retval))

    except:
        import sys
        exc_type, exc_value, exc_traceback = sys.exc_info()
        import traceback
        msg = repr(traceback.format_exception(exc_type, exc_value, exc_traceback))
        logger.warn(msg)
        import json
        retval['msg'] = msg
        return HttpResponse(json.dumps(retval),
               status=500)
    finally:
        pass

