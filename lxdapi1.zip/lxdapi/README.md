# lxdapi
This is the API that creates, updates, deletes Linux containers on a host where the API is run
