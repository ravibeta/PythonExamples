#!/bin/bash

set -e
FILEPATH=$(readlink -f $0)
APPDIR=$(dirname $0)/../
cd "$APPDIR"
if [ -f /usr/bin/pip3 ]
  	echo $APPDIR
then
       if [ ! -f $APPDIR/venv/bin/activate ]
       then
           echo $APPDIR
           virtualenv -p /usr/bin/python3 venv
       fi

       source venv/bin/activate
       pip3 install -r requirements.txt
fi

exit 0
