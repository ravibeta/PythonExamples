from django.views.decorators.csrf import csrf_exempt
from iamapi import settings
if 'test' not in settings.ENVIRONMENT:
   from cloudapi_utils.models import User
   from cloudapi_utils.serializers import UserSerializer
else:
   from django.contrib.auth.models import User
   from api.v1.serializers import DjangoUserSerializer
from django.core import serializers
from django.http import Http404, HttpResponse, QueryDict
from django.shortcuts import render
from rest_framework import exceptions, filters, generics, status, viewsets
from rest_framework.decorators import detail_route, api_view
from rest_framework.response import Response
import logging
logging.basicConfig()
logger = logging.getLogger(__name__)

# Create your views here.

key = settings.GRPMGR_API_KEY 
import requests
import time
import requests
import json
import urllib
import base64
import datetime
import jwt

#constant
base_cname=settings.GRPMGR_SERVER
origin=settings.GRPMGR_ORIGIN 
destination = settings.GRPMGR_DEST 
sharedSecret = settings.GRPMGR_SECRET 

class ContainerViewSet(viewsets.ModelViewSet):

  def cmd_execute(self, cmd):
        import subprocess
        from threading import Timer
        from subprocess import Popen, PIPE
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        kill_proc = lambda p: p.kill()
        timer = Timer(10, kill_proc, [process])
        output = ''
        try:
          timer.start()
          output, stderr = process.communicate()
        finally:
          timer.cancel()
        return output


  def all(self):
      text = self.cmd_execute("lxc list")
      #logger.info("lxc list returned: " + text)
      text = text.split("\n")
      containers = []
      keys = []
      for line in text:
          if line.startswith('+') == False:
               container = {}
               parts = [ x.strip() for x in line.split('|') ]
               if parts[0] == "NAME":
                  print('Line1='+line)
                  keys = [ x for x in parts ]
               else:
                  print('Line2='+line)
                  container["NAME"] = parts[0]
                  container["STATUS"] = parts[1]
                  container["IPv4"] = parts[2]
                  containers.append(container)
      return containers
      pass


  def get(self, name):
      container = None
      containers = self.all()
      for item in containers:
          if item["NAME"] == name:
             container = item
      return container



  def list(self, request):
    import json
    containers = []
    retval = {'status':'error', 'msg':'Opertion Failed.', 'containers': containers}
    try:

        email = request.META.get('HTTP_X_LDAP')
        if email:
           logger.info('requested by ' + email)
        else:
           retval['msg'] = 'Unauthorized.'
           return  HttpResponse(json.dumps(retval),
                   status=401)

        containers = self.all()
        #base_url = base_cname 
        #info = { 'url' : base_url,
        #         'headers' : headers,
        #       }
        #logger.info(repr(info))
        #r = requests.get(base_url, headers=headers)
        #logger.info("\r\n" + str(r.status_code) + " : " + repr(r.text))
        #status = r.status_code
        #content = r.text
        return HttpResponse(json.dumps(containers))
    except:
        import sys
        exc_type, exc_value, exc_traceback = sys.exc_info()
        import traceback
        msg = repr(traceback.format_exception(exc_type, exc_value, exc_traceback))
        logger.warn(msg)
        import json
        retval['msg'] = msg
        return HttpResponse(json.dumps(retval), 
               status=500)
    finally:
        pass
  
  def create(self, request):
    import json
    container = []
    name = ''
    retval = {'status':'error', 'msg':'Opertion Failed.', 'name': name}
    try:

        email = request.META.get('HTTP_X_LDAP')
        if email:
           logger.info('requested by ' + email)
        else:
           retval['msg'] = 'Unauthorized.'
           return  HttpResponse(json.dumps(retval),
                   status=401)

        name = request.data.get(name)
        if name:
           logger.info('requesting container by name :' + name)
        else:
           retval['msg'] = 'Invalid name.'
           return  HttpResponse(json.dumps(retval),
                   status=400)

        text = self.cmd_execute("lxc launch ubuntu:14.04 " + name)
        #logger.info("lxc launch returned: " + text)

        container = self.get(name)
        if container == None:
           retval['msg'] = 'Create container failed.'
           return  HttpResponse(json.dumps(retval),
                   status=500)

        return HttpResponse(json.dumps(container))
    except:
        import sys
        exc_type, exc_value, exc_traceback = sys.exc_info()
        import traceback
        msg = repr(traceback.format_exception(exc_type, exc_value, exc_traceback))
        logger.warn(msg)
        import json
        retval['msg'] = msg
        return HttpResponse(json.dumps(retval),
               status=500)
    finally:
        pass
  
  @detail_route(methods=['post'], url_path='purge')
  def purge(self, request, pk=None):
    import json
    container = []
    name = ''
    retval = {'status':'error', 'msg':'Opertion Failed.', 'name': name}
    try:
        owner = 'rajamani'
    
        email = request.META.get('HTTP_X_LDAP')
        if email:
           logger.info('requested by ' + email)
        else:
           retval['msg'] = 'Unauthorized.'
           return  HttpResponse(json.dumps(retval),
                   status=401)
     
        name = request.data.get(name)
        if name:
           logger.info('requesting container by name :' + name)
        else:
           retval['msg'] = 'Invalid name.'
           return  HttpResponse(json.dumps(retval), 
                   status=400)

        text = self.cmd_execute("lxc launch ubuntu:14.04 " + name)
        #logger.info("lxc launch returned: " + text)
     
        container = self.get(name)
        if container == None:
           retval['msg'] = 'Container not found'
           return  HttpResponse(json.dumps(retval),
                   status=400)
        text = self.cmd_execute("lxc launch ubuntu:14.04 " + name)
        if text:
           retval['msg'] = 'Delete failed.'
           return  HttpResponse(json.dumps(retval),
                   status=500)
     
        return HttpResponse(json.dumps(container))
    except:
        import sys
        exc_type, exc_value, exc_traceback = sys.exc_info()
        import traceback
        msg = repr(traceback.format_exception(exc_type, exc_value, exc_traceback))
        logger.warn(msg)
        import json
        retval['msg'] = msg
        return HttpResponse(json.dumps(retval),
               status=500)
    finally:
        pass 
      


