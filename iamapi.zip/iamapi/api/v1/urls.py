from django.conf.urls import patterns, include, url
from api.v1 import views
from api.v1 import routers

test_api_call = patterns('',
#    url(r'tests', views.TestViewSet.as_view())
)

router = routers.IAMRouter(trailing_slash=False)
router.register(r'container', views.ContainerViewSet, base_name='container')
router.register(r'container/$', views.ContainerViewSet, base_name='container')

urlpatterns = patterns('',
    url(r'^', include(test_api_call, namespace="test_api_call")),
    url(r'^', include(router.urls)),
)
