from rest_framework.authtoken.models import Token
from django.core.urlresolvers import reverse
from rest_framework.test import APIRequestFactory
from rest_framework.test import APIClient
from rest_framework import status
from django.test import TestCase
import unittest
from unittest.mock import patch
from unittest.mock import MagicMock
from api.v1.views import ContainerViewSet


class ContainerTestCase(TestCase):
#    def __init__(self):
#        self.client = APIClient()

    def setUp(self):
        self.url = reverse('container-list')
        print('url : -- ' + str(self.url) + ' -- ')
        self.client = APIClient(HTTP_X_LDAP='rajamani')

    @patch('api.v1.views.ContainerViewSet.cmd_execute')
    def test_list_group(self, mock_requests):
        self.setUp()
        mock_requests.return_value = '  \
+++++++++++++++++++++++++++++++++++++\n\
|   NAME   |   STATUS  |     IPV4   |\n\
+++++++++++++++++++++++++++++++++++++\n\
|workhorse |  Running  | 10.5.10.10 |\n\
+++++++++++++++++++++++++++++++++++++'
        response = self.client.get(self.url)
        print('response code: ' + str(response.status_code) + ' data: ' + str(response.content))
        self.assertTrue(str(response.status_code)=='200')
    
    @patch('api.v1.views.ContainerViewSet.cmd_execute')
    @patch('api.v1.views.ContainerViewSet.get')
    def test_create_group(self, mock_requests, mock_get):
        self.setUp()
        mock_requests.return_value = ""
        mock_get.return_value = {"NAME": "workhorse1", "STATUS": "Running", "IPV4": "10.5.10.11"}
        response = self.client.post(self.url, {'name':'workhorse1'})#, format='json')
        print('response code: ' + str(response.status_code) + ' data: ' + str(response.content))
        self.assertTrue(str(response.status_code)=='200')

    @patch('api.v1.views.ContainerViewSet.cmd_execute')    
    @patch('api.v1.views.ContainerViewSet.get')
    def test_delete_group(self, mock_requests, mock_get):
        self.setUp()
        mock_requests.return_value = ""
        mock_get.return_value = {"NAME": "workhorse1", "STATUS": "Running", "IPV4": "10.5.10.11"}
        response = self.client.post(self.url + '0/purge', {'name':'workhorse1'})
        print('response code: ' + str(response.status_code) + ' data: ' + str(response.content))
        self.assertTrue(str(response.status_code)=='200')
