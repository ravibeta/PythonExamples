from django.conf.urls import patterns, include, url
from django.contrib import admin
from rest_framework import routers
from django.conf.urls.static import static
from django.conf import settings

admin.autodiscover()

urlpatterns = patterns('',
    url(r'^lxd/', include('api.urls')),
    url(r'^documentation', include('rest_framework_swagger.urls')),
)+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

