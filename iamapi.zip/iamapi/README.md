# iamapi
This is the API that creates, updates, deletes AD Groups such that the owners for those groups can manage it themselves using https://iam-dev.corp.adobe.com
In the production, the API will manage groups such that they appear on https://iam.corp.adobe.com
