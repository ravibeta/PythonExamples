# lxdapi
Documentation at https://linuxcontainers.org/lxd/try-it/ 
