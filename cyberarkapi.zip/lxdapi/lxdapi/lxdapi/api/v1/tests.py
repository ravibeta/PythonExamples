from __future__ import unicode_literals
from django.test import TestCase, RequestFactory
from datetime import datetime, date, time
from lxdapi import settings

import json
import base64
import uuid

try:
    import urllib.parse as urllib
except ImportError:
    import urllib

from django.core.urlresolvers import reverse
from django.views.generic import View


def testThis():
    t = ModelTestCase()
    t.test_model()

