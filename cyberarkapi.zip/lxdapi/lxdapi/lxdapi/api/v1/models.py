from django.db import models
from django.db.models import Q
from django.core import validators
from rest_framework import exceptions
import uuid

