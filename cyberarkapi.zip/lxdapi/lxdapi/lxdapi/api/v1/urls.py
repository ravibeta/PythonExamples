from django.conf.urls import patterns, include, url
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter(trailing_slash=False)
router.register(r'lxd', views.ResourceLeaseViewSet, base_name='lxd')

urlpatterns = patterns('',
    url(r'^', include(router.urls), name='lxd')
)
