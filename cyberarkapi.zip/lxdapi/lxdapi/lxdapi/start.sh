python manage.py runserver 10.5.250.38:8080
