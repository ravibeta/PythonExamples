#from .models import Metric
#default_app_config = 'metricapi.MetricConfig'

