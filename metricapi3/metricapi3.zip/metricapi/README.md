#  API to receive callbacks from AWS CloudWatch
#  Please see github.com/ravibeta/PHPSamples for how to collect and archive metrics into a table and generate a bill
#  This API subscribes to SNS messages by creating a subscription with its endpoint and the billing topic ARN on the SNS console
